<?php echo e($slot); ?>

<?php /**PATH /Users/ishaqkhan/sites/ishaqDev/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>