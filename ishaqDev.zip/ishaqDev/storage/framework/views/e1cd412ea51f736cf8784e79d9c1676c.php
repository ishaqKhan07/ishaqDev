<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\ishaqDev\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>