<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Notifications\InvoicePaid;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
    public function index(){


        DB::connection()->enableQueryLog();

        $user  = User::isEmail("ishaqkhan00023@gmail.com")->first();


        $querieslog = DB::getQueryLog();

        dd($querieslog);



        dd($user);

        try {
            User::create([
                "name"=>"admin",
                "email"=>"test123@gmailss.comqqssss",
                "password"=>bcrypt("admin")
            ]);

        }catch (\ErrorException $exception){
            die($exception->getMessage() . " at line no: " . $exception->getLine());
        }catch (\Exception $exception){
            echo $exception->getMessage();
        }

        dd('asd');

        $user = User::find(1);

        $user->name = "ishaqq";
        $user->email = "test@ishaqq.com";

        $user->save();

        dd($user);

        dd($user->name);

//        $products = User::all()->chunk(4);



        $orders = User::all()->reject(function ($order) {
            return $order->id > 5;
        });


        dd($orders);

        $user = User::find(1);

        $invoice = "test invoice";

        $user->notify(new InvoicePaid($invoice));

        dd($user);

        return view('welcome');
    }
}


