<?php

namespace App\Jobs;

use App\Notifications\InvoicePaid;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendEmailJob implements ShouldQueue
{
    use Queueable;
    protected $user;
    protected $deposit_amount;
    /**
     * Create a new job instance.
     */
    public function __construct($user,$depositAmount)
    {
        $this->user = $user;
        $this->deposit_amount = $depositAmount;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        $this->user->notify(new InvoicePaid($this->deposit_amount));
    }
}
