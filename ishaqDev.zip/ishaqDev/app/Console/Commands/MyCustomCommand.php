<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;

class MyCustomCommand extends Command
{
    protected $signature = 'test:command';
    protected $description = 'This is a custom command.';


    public function __construct()
    {
        parent::__construct();
    }


    public function handle()
    {
        $this->info('Running Test Command!');

        $email = random_int(100, 999).'ishaq@gmail.com';
        User::create([
            "name" => "ishaq",
            "email" => $email,
            "password" => Hash::make($email),
        ]);

        $this->info("Test Command Ended!");
    }
}
